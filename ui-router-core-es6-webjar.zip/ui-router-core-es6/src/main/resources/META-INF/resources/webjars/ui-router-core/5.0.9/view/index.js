export * from "./view.js";
//# sourceMappingURL=index.js.map
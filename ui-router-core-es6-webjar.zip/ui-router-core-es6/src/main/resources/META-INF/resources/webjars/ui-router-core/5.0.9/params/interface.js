/**
 * @coreapi
 * @module params
 */ /** for typedoc */
//# sourceMappingURL=interface.js.map
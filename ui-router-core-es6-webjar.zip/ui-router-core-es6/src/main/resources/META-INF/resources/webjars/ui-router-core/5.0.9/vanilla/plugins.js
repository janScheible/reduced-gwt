/**
 * @internalapi
 * @module vanilla
 */
/** */
import { BrowserLocationConfig } from "./browserLocationConfig.js";
import { HashLocationService } from "./hashLocationService.js";
import { locationPluginFactory } from "./utils.js";
import { PushStateLocationService } from "./pushStateLocationService.js";
import { MemoryLocationService } from "./memoryLocationService.js";
import { MemoryLocationConfig } from "./memoryLocationConfig.js";
import { $injector } from "./injector.js";
import { $q } from "./q.js";
import { services } from "../common/coreservices.js";
export function servicesPlugin(router) {
    services.$injector = $injector;
    services.$q = $q;
    return { name: "vanilla.services", $q: $q, $injector: $injector, dispose: function () { return null; } };
}
/** A `UIRouterPlugin` uses the browser hash to get/set the current location */
export var hashLocationPlugin = locationPluginFactory('vanilla.hashBangLocation', false, HashLocationService, BrowserLocationConfig);
/** A `UIRouterPlugin` that gets/sets the current location using the browser's `location` and `history` apis */
export var pushStateLocationPlugin = locationPluginFactory("vanilla.pushStateLocation", true, PushStateLocationService, BrowserLocationConfig);
/** A `UIRouterPlugin` that gets/sets the current location from an in-memory object */
export var memoryLocationPlugin = locationPluginFactory("vanilla.memoryLocation", false, MemoryLocationService, MemoryLocationConfig);
//# sourceMappingURL=plugins.js.map
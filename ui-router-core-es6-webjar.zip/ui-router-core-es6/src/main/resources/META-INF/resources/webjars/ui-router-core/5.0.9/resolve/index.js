/** @module resolve */ /** for typedoc */
export * from "./interface.js";
export * from "./resolvable.js";
export * from "./resolveContext.js";
//# sourceMappingURL=index.js.map
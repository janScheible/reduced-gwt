/**
 * @internalapi
 * @module vanilla
 */
/** */
export * from "./vanilla/index.js";
//# sourceMappingURL=vanilla.js.map
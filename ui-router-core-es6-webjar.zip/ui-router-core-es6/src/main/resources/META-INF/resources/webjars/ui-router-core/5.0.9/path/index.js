/** @module path */ /** for typedoc */
export * from "./pathNode.js";
export * from "./pathFactory.js";
//# sourceMappingURL=index.js.map